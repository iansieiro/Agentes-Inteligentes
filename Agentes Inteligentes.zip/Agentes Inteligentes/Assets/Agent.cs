using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Agent : MonoBehaviour
{
    public Vector3 targetPosition;
    public float maxSpeed = 5.0f;
    public float newtonForce = 32.0f;
    public float minDistanceToTarget = 0.02f;
    public float arrivalDistance = 5.0f;
    public float raycastDistance = 10.0f;
    public float raycastAngleVariation = 45.0f;
    public Vector3 currentVelocity = Vector3.zero;
    public bool enableraycastGizmos = true;
    float maxBreakSpeed = 0.01f;

    Vector3 Truncate(Vector3 dir, float maxMagnitude)
    {
        Vector3 normalizedVector = dir.normalized;

        if(dir.magnitude < maxMagnitude)
            return dir;

        return normalizedVector * maxMagnitude;
    }

    void ChooseNewTarget()
    {
        targetPosition = new Vector3(Random.Range(-1.0f, 1.0f) * 32.0f, Random.Range(-1.0f, 1.0f) * 18.0f, 75.0f);
    }

    void UpdateVelocity(Vector3 SteeringForce)
    {
        float mass = GetComponent<Rigidbody>().mass;

        Vector3 acceleration = SteeringForce / mass;

        currentVelocity += acceleration * Time.deltaTime;
        currentVelocity = Truncate(currentVelocity, maxSpeed);
    }

    void UpdatePosition()
    {
        Vector3 newPosition = transform.position + currentVelocity * Time.deltaTime;

        transform.LookAt(newPosition);

        transform.position = newPosition;
    }

    Vector3 ChooseBestDirection()
    {
        RaycastHit hit;
        Vector3 desiredDirection = (targetPosition - transform.position).normalized;

        if(Physics.Raycast(transform.position, desiredDirection, out hit, raycastDistance) == false)
            return desiredDirection;
        
        float bestCollisionDistance = 0.0f;
        Vector3 bestDir = Vector3.forward;

        if(Physics.Raycast(transform.position, Vector3.forward, out hit, raycastDistance) == false)
            return Vector3.forward;
        else
            bestCollisionDistance = Vector3.Distance(transform.position, hit.point);

        Vector3 leftDiagonal = (Quaternion.AngleAxis(-raycastAngleVariation, Vector3.forward) * currentVelocity).normalized;
        Vector3 rightDiagonal = (Quaternion.AngleAxis(raycastAngleVariation, Vector3.forward) * currentVelocity).normalized;

        if(Physics.Raycast(transform.position, leftDiagonal, out hit, raycastDistance) == false)
            return leftDiagonal;

        float leftDistance = Vector3.Distance(transform.position, hit.point);
        if(leftDistance > bestCollisionDistance)
        {
            bestCollisionDistance = leftDistance;
            bestDir = leftDiagonal;
        }

        if(Physics.Raycast(transform.position, rightDiagonal, out hit, raycastDistance) == false)
            return rightDiagonal;

        float rightDistance = Vector3.Distance(transform.position, hit.point);
        if(rightDistance > bestCollisionDistance)
        {
            bestCollisionDistance = rightDistance;
            bestDir = rightDiagonal;
        }

        return bestDir;
    }

    void DoSeekArrivalBehavior()
    {
        float distance = Vector3.Distance(targetPosition, transform.position);

        if(distance < minDistanceToTarget)
        {
            ChooseNewTarget();
            return;
        }

        Vector3 directionToTarget = ChooseBestDirection();

        UpdateVelocity(directionToTarget * newtonForce);

        if(distance < arrivalDistance)
        {
            float newSpeed =(maxBreakSpeed * distance) / arrivalDistance;
            newSpeed = (newSpeed > 0.5f) ? newSpeed : 0.5f;

            currentVelocity = currentVelocity.normalized * newSpeed;
        }
        else
        {
            maxBreakSpeed = currentVelocity.magnitude;
        }
    }

    private void Start() {
        ChooseNewTarget();
    }

    private void Update() {
        DoSeekArrivalBehavior();
        UpdatePosition();
    }

    private void OnDrawGizmos() {
        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(targetPosition, 0.5f);

        if(enableraycastGizmos)
        {
            return;
        }

        Vector3 forward = currentVelocity.normalized;
        Vector3 left = Quaternion.AngleAxis(-raycastAngleVariation, Vector3.forward) * forward;
        Vector3 right = Quaternion.AngleAxis(raycastAngleVariation, Vector3.forward) * forward;

        Gizmos.color = Color.white;

        Gizmos.DrawLine(transform.position, transform.position + forward * raycastDistance);
        Gizmos.DrawLine(transform.position, transform.position + left * raycastDistance);
        Gizmos.DrawLine(transform.position, transform.position + right * raycastDistance);
    }
}
