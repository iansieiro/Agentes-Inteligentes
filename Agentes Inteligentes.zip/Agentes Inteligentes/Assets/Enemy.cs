using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public enum ENEMY_BEHAVIOUR
    {
        SEEK,
        PERSUIT
    };
    public ENEMY_BEHAVIOUR Behaviour = ENEMY_BEHAVIOUR.SEEK;
    public float MaxSpeed = 5.0f;
    public float NewtonForce = 32.0f;
    public float DistanceToTargetToReduceSpeed = 2.0f;
    public float RaycastDistance = 10.0f;
    public float RaycastAngleVariation = 25.0f;
    public Vector3 CurrentVelocity = Vector3.zero;
    float MaxBreakSpeed = 0.01f;
    Transform Player;
    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.Find("Player").transform;

        if(Behaviour == ENEMY_BEHAVIOUR.PERSUIT)
        {
            GetComponent<Renderer>().material.color = Color.red;
        }
        else
        {
            GetComponent<Renderer>().material.color = Color.green;
        }
    }

    Vector3 Truncate(Vector3 dir, float maxMagnitude)
    {
    // Tirando a escala do vetor
    Vector3 normalizedVector = dir.normalized;

    if (dir.magnitude <= maxMagnitude)
    return dir;

    return normalizedVector * maxMagnitude;
    }

    // Atualiza velocidade baseado na força de direção
    void UpdateVelocity(Vector3 SteeringForce)
    {
    float mass = GetComponent<Rigidbody>().mass;

    Vector3 acceleration = SteeringForce / mass;

    CurrentVelocity += acceleration * Time.deltaTime;

    CurrentVelocity = Truncate(CurrentVelocity, MaxSpeed);
    }

    void UpdatePosition()
    {
        Vector3 newPosition = transform.position + CurrentVelocity * Time.deltaTime;
        newPosition.y = transform.position.y;

        transform.LookAt(newPosition);
        transform.position = newPosition;
    }
    void ChooseBestDirection(Vector3 desiredDir, Vector3 raycastDir, ref float bestSolutionValue, ref Vector3 bestDir)
    {
        RaycastHit hit;

        float angle = Mathf.Acos(Vector3.Dot(desiredDir.normalized, raycastDir.normalized));
        float raycastDistanceReached = RaycastDistance;
        if (Physics.Raycast(transform.position, raycastDir, out hit, RaycastDistance))
            raycastDistanceReached = Vector3.Distance(transform.position, hit.point);

        float solutionValue = raycastDistanceReached + (1.5f - angle);
        if (solutionValue > bestSolutionValue)
        {
            bestSolutionValue = solutionValue;
            bestDir = raycastDir;
        }
    }

    Vector3 ChooseBestDirection()
    {
        RaycastHit hit;
        Vector3 desiredDirection;
        Vector3 velocityNormalized = CurrentVelocity.normalized;
        float distanceToTarget = Vector3.Distance(transform.position, Player.position);
        Vector3 targetPosition = Player.position;
        if (Behaviour == ENEMY_BEHAVIOUR.PERSUIT)
        {
            Player playerBehaviour = Player.GetComponent<Player>();
            targetPosition += playerBehaviour.Velocity.normalized * distanceToTarget;

        }
        desiredDirection = (targetPosition - transform.position).normalized;
        float rayTargetDistance = Vector3.Distance(transform.position, targetPosition);
        rayTargetDistance = (rayTargetDistance < RaycastDistance) ? rayTargetDistance: RaycastDistance;

        if (Physics.Raycast(transform.position, desiredDirection, out hit, rayTargetDistance) == false)
            return desiredDirection;
        float bestSolutionValue = Vector3.Distance(transform.position, hit.point);
        Vector3 bestDir = desiredDirection;
        Vector3 leftDiagonal = (Quaternion.AngleAxis(-RaycastAngleVariation, Vector3.up)* CurrentVelocity).normalized;
        Vector3 rightDiagonal = (Quaternion.AngleAxis(RaycastAngleVariation, Vector3.up)* CurrentVelocity).normalized;
        Vector3 left = (Quaternion.AngleAxis(-90.0f, Vector3.up)* CurrentVelocity).normalized;
        Vector3 right = (Quaternion.AngleAxis(90.0f, Vector3.up)* CurrentVelocity).normalized;

        ChooseBestDirection(desiredDirection, velocityNormalized, ref bestSolutionValue, ref bestDir);
        ChooseBestDirection(desiredDirection, leftDiagonal, ref bestSolutionValue, ref bestDir);
        ChooseBestDirection(desiredDirection, rightDiagonal, ref bestSolutionValue, ref bestDir);
        ChooseBestDirection(desiredDirection, left, ref bestSolutionValue, ref bestDir);
        ChooseBestDirection(desiredDirection, right, ref bestSolutionValue, ref bestDir);
        return bestDir;
    }
    void DoBehaviour()
    {
        Vector3 directionToTarget = ChooseBestDirection();
        UpdateVelocity(directionToTarget * NewtonForce);
        float distance = Vector3.Distance(Player.position, transform.position);
        if (distance <= DistanceToTargetToReduceSpeed)
        {
            float newSpeed = (MaxBreakSpeed * distance) / DistanceToTargetToReduceSpeed;
            newSpeed = (newSpeed > 1.5f) ? newSpeed: 1.5f;
            CurrentVelocity = CurrentVelocity.normalized * newSpeed;
        }
        else 
        {
            MaxBreakSpeed = CurrentVelocity.magnitude;
        }
    }

    private void OnCollisionEnter(Collision collision) {
        if(collision.other.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            Application.LoadLevel("Aula2");
        }
    }

    // Update is called once per frame
    void Update()
    {
        DoBehaviour();
        UpdatePosition();
    }
}
