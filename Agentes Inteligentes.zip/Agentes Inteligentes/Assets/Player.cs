using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 7.5f;
    public Vector3 Velocity = Vector3.zero;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Velocity = Vector3.zero;
        if (Input.GetKey(KeyCode.A))
            Velocity += Vector3.left;
        if(Input.GetKey(KeyCode.W))
            Velocity += Vector3.forward;
        if (Input.GetKey(KeyCode.S))
            Velocity += Vector3.back;
        if (Input.GetKey(KeyCode.D))
            Velocity += Vector3.right;
        Velocity = Velocity.normalized * speed;
        Vector3 newPosition = transform.position + Velocity * Time.deltaTime;
        newPosition.y = transform.position.y;
        transform.position = newPosition;
    }
}
