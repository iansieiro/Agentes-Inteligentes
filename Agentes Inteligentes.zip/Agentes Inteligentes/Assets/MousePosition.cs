using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MousePosition : MonoBehaviour
{
    void Update()
    {
        if(Input.GetMouseButton(0) == false)
            return;

        Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        pos.z = transform.position.z;

        transform.position = pos;
    }
}
